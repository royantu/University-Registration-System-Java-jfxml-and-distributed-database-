/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
//import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class HomeController implements Initializable {

     @FXML
     private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
     @FXML
     private void LogOutbutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void Coursebutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Course.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void Studentbutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Student.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void DepartmentButton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Department.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void InstructorButton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Instructor.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void SemesterButton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Semester.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
     @FXML
     private void HelpButton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Help.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  

    @FXML
    private void yourdetailsbutton(ActionEvent event) throws IOException {
        Parent regParent = FXMLLoader.load(getClass().getResource("YOUR_DETAILS.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
   
     
    
}
