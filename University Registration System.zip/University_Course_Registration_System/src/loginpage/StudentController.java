/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import static loginpage.FXMLDocumentController.mail;
import static loginpage.FXMLDocumentController.name;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class StudentController implements Initializable {
    FXMLDocumentController obj = new FXMLDocumentController();
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";

    @FXML
    private JFXTextField idtf;
    @FXML
    private JFXTextField intaketf;
    @FXML
    private JFXTextField contacttf;
    @FXML
    private JFXTextField nametfsi;
    @FXML
    private JFXTextField mailtfsi;
    
    @FXML
     private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
     @FXML
     private void Homebutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                 Connection dbConnection = null;
                 Statement statement = null;
                 dbConnect db = new dbConnect();

        try {
            String querySQL = "SELECT STUDENT_NAME,STUDENT_EMAIL FROM STUDENT WHERE STUDENT_NAME = '" + name + "' AND STUDENT_EMAIL = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String X = rs.getString(1);
                String Y = rs.getString(2);
                nametfsi.setText(X);
                mailtfsi.setText(Y);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        // TODO
    }    

    @FXML
    private void submitbutton(ActionEvent event) {
        Connection dbConnection = null;
        Statement statement = null;
        String A,B,C;
        A=idtf.getText();
        B=intaketf.getText();
        C=contacttf.getText();
        String querySTU ="UPDATE STUDENT SET STUDENT_ID = '" + A + "',STUDENT_INTAKE='" + B + "',STUDENT_CONTACT='" + C + "' WHERE STUDENT_NAME = '" + name + "' AND STUDENT_EMAIL = '" + mail + "' ";
        String queryINS = "INSERT INTO INSTRUCTOR"
                + "(STUDENT_NAME,STUDENT_ID)"
                + "VALUES('"+name+"','"+A+"')";   
        
        String queryDEPT = "INSERT INTO DEPARTMENT"
                + "(STUDENT_NAME,STUDENT_ID)"
                + "VALUES('"+name+"','"+A+"')"; 
        String queryCOUR = "INSERT INTO COURSE"
                + "(STUDENT_NAME,STUDENT_ID)"
                + "VALUES('"+name+"','"+A+"')"; 
        String querySEM = "INSERT INTO SEMESTER"
                + "(STUDENT_NAME,STUDENT_ID)"
                + "VALUES('"+name+"','"+A+"')"; 

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(querySTU);
            System.out.println(queryINS);
            System.out.println(queryDEPT);
            System.out.println(queryCOUR);
            System.out.println(querySEM);
            statement.executeUpdate(querySTU);
            statement.executeUpdate(queryINS);
            statement.executeUpdate(queryDEPT);
            statement.executeUpdate(queryCOUR);
            statement.executeUpdate(querySEM);
           
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        } 
        
    }
     
  private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    
}   
}
