/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import static loginpage.FXMLDocumentController.mail;
import static loginpage.FXMLDocumentController.name;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class YOUR_DETAILSController implements Initializable {
    FXMLDocumentController obj = new FXMLDocumentController();
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";

    @FXML
    private Label tfname;
    @FXML
    private Label tfmail;
    @FXML
    private Label tfid;
    @FXML
    private Label tfcon;
    @FXML
    private Label tfdeptno;
    @FXML
    private Label tfdeptbuil;
    @FXML
    private Label tfdeptfloor;
    @FXML
    private Label tfinsname;
    @FXML
    private Label tfinscon;
    @FXML
    private Label tfinsroom;
    @FXML
    private Label tfinsmail;
    @FXML
    private Label tfsemno;
    @FXML
    private Label tftotalcredit;
    @FXML
    private Label tfsemname;
    @FXML
    private Label tftheorycredit;
    @FXML
    private Label tflabcredit;
    @FXML
    private Label tfdept;
    @FXML
    private Label tfintake;
    @FXML
    private Label tfct1;
    @FXML
    private Label tfct2;
    @FXML
    private Label tfct3;
    @FXML
    private Label tfct4;
    @FXML
    private Label tfct5;

    @FXML
    private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                 Connection dbConnection = null;
                 Statement statement = null;
                 dbConnect db = new dbConnect();

        try {
            String querySQL = "SELECT STUDENT_NAME,EMAIL_ID FROM REGISTRATION WHERE STUDENT_NAME = '" + name + "' AND EMAIL_ID = '" + mail + "'  ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String X = rs.getString(1);
                String Y = rs.getString(2);
                tfname.setText(X);
                tfmail.setText(Y);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
        try {
            String querySQL = "SELECT INSTRUCTOR_NAME,INSTRUCTOR_ROOM,INSTRUCTOR_CONTACT,INSTRUCTOR_EMAIL FROM INSTRUCTOR WHERE STUDENT_NAME = '" + name + "' ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String A = rs.getString(1);
                String B = rs.getString(2);
                String C = rs.getString(3);
                String D = rs.getString(4);
                tfinsname.setText(A);
                tfinsroom.setText(B);
                tfinscon.setText(C);
                tfinsmail.setText(D);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
        
        try {
            String querySQL = "SELECT STUDENT_ID,STUDENT_CONTACT,STUDENT_INTAKE FROM STUDENT WHERE STUDENT_NAME = '" + name + "' AND STUDENT_EMAIL='"+mail+"' ";
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySQL);

            while (rs.next()) {
                String A = rs.getString(1);
                String B = rs.getString(2);
                String C = rs.getString(3);
                
                tfid.setText(A);
                tfcon.setText(B);
                tfintake.setText(C);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        try {
            String queryDEP = "SELECT DEPARTMENT_NO,DEPARTMENT_NAME,DEPARTMENT_BUILDING,DEPARTMENT_FLOOR_NO FROM DEPARTMENT WHERE STUDENT_NAME = '" + name + "'  ";
            System.out.println(queryDEP);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(queryDEP);

            while (rs.next()) {
                String A = rs.getString(1);
                String B = rs.getString(2);
                String C = rs.getString(3);
                String D = rs.getString(4);
                
                tfdeptno.setText(A);
                tfdept.setText(B);
                tfdeptbuil.setText(C);
                tfdeptfloor.setText(D);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
        try {
            String queryCOUR = "SELECT COURSE_1,COURSE_2,COURSE_3,COURSE_4,COURSE_5 FROM COURSE WHERE STUDENT_NAME = '" + name + "'  ";
            System.out.println(queryCOUR);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(queryCOUR);

            while (rs.next()) {
                String A = rs.getString(1);
                String B = rs.getString(2);
                String C = rs.getString(3);
                String D = rs.getString(4);
                String E = rs.getString(5);
                
                tfct1.setText(A);
                tfct2.setText(B);
                tfct3.setText(C);
                tfct4.setText(D);
                tfct5.setText(E);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        
        
        try {
            String querySEM = "SELECT SEMESTER_NO,SEMESTER_NAME,TOTAL_CREDIT,LAB_CREDIT,THEORY_CREDIT FROM SEMESTER  WHERE STUDENT_NAME = '" + name + "'  ";
            System.out.println(querySEM);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(querySEM);

            while (rs.next()) {
                String A = rs.getString(1);
                String B = rs.getString(2);
                String C = rs.getString(3);
                String D = rs.getString(4);
                String E = rs.getString(5);
                
                tfsemno.setText(A);
                tfsemname.setText(B);
                tftotalcredit.setText(C);
                tflabcredit.setText(D);
                tftheorycredit.setText(E);
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }  
    
    

    @FXML
    private void homebutton(ActionEvent event) throws IOException {
        Parent regParent = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    
}
}
